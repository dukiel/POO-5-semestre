public class CommissionEmployee {
    private String firstName, lastName, socialSecurityNumber;
    private double grossSales, commissionRate;
    public CommissionEmployee(String first, String last, String ssn, double sales, double rate) {
        setFirstName(first);
        setLastName(last);
        setSocialSecurityNumber(ssn);
        setGrossSales(sales);
        setCommissionRate(rate);
    }
    public void setFirstName(String first) {
        firstName = first;
    } // end method setFirstName
    public String getFirstName() {
        return firstName;
    } // end method getFirstName
    public void setLastName(String last) {
        lastName = last;
    } // end method setLastName
    public String getLastName() {
        return lastName;
    } // end method getLastName
    public void setSocialSecurityNumber(String ssn) {
        socialSecurityNumber = ssn;
    } // end method setSocialSecurityNumber
    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    } // end method getSocialSecurityNumber
    public void setGrossSales( double sales ) {
        grossSales = ( sales < 0.0 ) ? 0.0 : sales;
    }
    public double getGrossSales() {
        return grossSales;
    } // end method getGrossSales
    public void setCommissionRate(double rate) {
        commissionRate = ( rate > 0.0 && rate < 1.0) ? rate : 0.0;
    }
    public double getCommissionRate() {
        return commissionRate;
    }
    public double earnings() {
        return commissionRate * grossSales;
    }
    public String toString() {
        return String.format ("%s: %s %s\n%s: %s\n%s: %.2f\n%s: %.2f",
                "commission employee: ", getFirstName(), getLastName(),
                "social security number: ", getSocialSecurityNumber(),
                "gross sales: ", getGrossSales(),
                "commission rate", getCommissionRate() );
    }
} // end class CommissionEmployee